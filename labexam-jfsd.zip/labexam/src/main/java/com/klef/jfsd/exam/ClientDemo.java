package com.klef.jfsd.exam;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        // Setup Hibernate session
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Insert records
        Customer customer1 = new Customer();
        customer1.setName("John Doe");
        customer1.setEmail("john.doe@example.com");
        customer1.setAge(25);
        customer1.setLocation("New York");

        Customer customer2 = new Customer();
        customer2.setName("Jane Smith");
        customer2.setEmail("jane.smith@example.com");
        customer2.setAge(30);
        customer2.setLocation("Los Angeles");

        session.save(customer1);
        session.save(customer2);

        transaction.commit();

        // Apply HCQL restrictions
        Criteria criteria = session.createCriteria(Customer.class);

        System.out.println("Customers with age > 25:");
        criteria.add(Restrictions.gt("age", 25));
        List<Customer> results = criteria.list();
        for (Customer c : results) {
            System.out.println(c.getName() + " - " + c.getLocation());
        }

        System.out.println("\nCustomers with location like 'Los%':");
        criteria = session.createCriteria(Customer.class);
        criteria.add(Restrictions.like("location", "Los%"));
        results = criteria.list();
        for (Customer c : results) {
            System.out.println(c.getName() + " - " + c.getLocation());
        }

        session.close();
        sessionFactory.close();
    }
}
